export const BOARD_SIZE = 5;
export const TILE = 96;
export const PIECE_SCALE = 0.6;
export const BACKGROUND_COLOR = '#0f0f13';
