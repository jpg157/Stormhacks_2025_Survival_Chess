import { Container, Graphics, Sprite, Texture } from 'pixi.js';
import { BOARD_SIZE, TILE, PIECE_SCALE } from '../config';
import { GameController } from '../controllers/GameController';

export class BoardView {
  public root = new Container();
  private tilesLayer = new Container();
  private piecesLayer = new Container();
  private selection: Graphics | null = null;

  constructor(
    private controller: GameController,
    private textures: Map<string, Texture>
  ) {
    this.root.addChild(this.tilesLayer, this.piecesLayer);
  }

  drawTiles(): void {
    this.tilesLayer.removeChildren();

    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        const dark = ((r + c) % 2) === 0;
        const g = new Graphics();
        g.beginFill(dark ? 0x2b2f3a : 0x3b4150);
        g.drawRect(0, 0, TILE, TILE);
        g.endFill();
        g.x = c * TILE;
        g.y = r * TILE;

        g.eventMode = 'static';
        g.cursor = 'pointer';
        g.on('pointertap', () => this.onTileClick(r, c));

        this.tilesLayer.addChild(g);
      }
    }

    this.selection = new Graphics();
    this.selection.lineStyle(4, 0xffcc33);
    this.selection.drawRect(0, 0, TILE, TILE);
    this.selection.visible = false;
    this.tilesLayer.addChild(this.selection);
  }

  updatePieces(): void {
    this.piecesLayer.removeChildren();

    const board = this.controller.getBoard();
    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        const piece = board[r][c];
        if (!piece) continue;

        const tex = this.textures.get(piece.getType());
        if (!tex) continue;

        const sp = new Sprite(tex);
        sp.anchor.set(0.5);
        sp.scale.set(PIECE_SCALE);
        sp.x = c * TILE + TILE / 2;
        sp.y = r * TILE + TILE / 2;

        sp.eventMode = 'static';
        sp.cursor = 'pointer';
        sp.on('pointertap', () => this.onTileClick(r, c));

        this.piecesLayer.addChild(sp);
      }
    }

    const sel = this.controller.getSelection();
    if (this.selection) {
      if (sel) {
        this.selection.visible = true;
        this.selection.x = sel.col * TILE;
        this.selection.y = sel.row * TILE;
      } else {
        this.selection.visible = false;
      }
    }
  }

  private onTileClick(row: number, col: number): void {
    const board = this.controller.getBoard();
    const sel = this.controller.getSelection();

    if (!sel) {
      // no selection yet → try to select this tile if it has a piece
      this.controller.select(row, col);
      this.updatePieces();
      return;
    }

    // Clicking selected tile toggles off
    if (sel.row === row && sel.col === col) {
      this.controller.clearSelection();
      this.updatePieces();
      return;
    }

    // Try move; if it fails and clicked has a piece, switch selection
    const moved = this.controller.tryMove(row, col);
    if (!moved && board[row][col]) {
      this.controller.select(row, col);
    }
    this.updatePieces();
  }
}
