import { Container } from 'pixi.js';
import { createApp, centerStage } from './game/ui/app';
import { loadPieceTextures } from './game/ui/assets';
import { GameBoard } from './game/game_board/GameBoard';
import { GameController } from './game/controllers/GameController';
import { BoardView } from './game/ui/BoardView';

async function start(): Promise<void> {
  const app = await createApp();

  const root = new Container();
  app.stage.addChild(root);
  centerStage(app, root);

  const textures = await loadPieceTextures();

  const game = new GameBoard();
  const controller = new GameController(game);
  const view = new BoardView(controller, textures);

  root.addChild(view.root);

  view.drawTiles();
  view.updatePieces();
}

start();
